# Prompt Templates

This directory will contain prompt templates for the Antigravity agents.

Currently empty - prompts will be added as agents are implemented.
